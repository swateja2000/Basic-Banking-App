This is a basic banking application created using Java and Android Studio. 
